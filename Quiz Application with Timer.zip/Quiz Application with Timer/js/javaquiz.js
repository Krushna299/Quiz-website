let questions = [
  {
    numb: 1,
    question: "java.util.Collections is a:",
    answer: "Class",
    options: [
      "Class",
      "Interface",
      "Object",
      "None of the above"
    ]
  },
  {
    numb: 2,
    question: "Methods such as reverse, shuffle are offered in:",
    answer: " Collections",
    options: [
      " Object",
      " Collection",
      " Collections",
      "Apache Commons Collections"
    ]
  },
  {
    numb: 3,
    question: "Which allows the storage of a null key and null values?",
    answer: "HashMap",
    options: [
      " Hashtable",
      "HashMap",
      "None of the above",
      "Hashelement"

    ]
  },
  {
    numb: 4,
    question: "Which interface should be implemented for sorting on basis of many criteria’s?",
    answer: "Comparator",
    options: [
      "Comparator",
      " Comparable",
      "Serializable",
      "None of the above"
    ]
  },
  {
    numb: 5,
    question: "What guarantees type-safety in a collection? ",
    answer: "Generics",
    options: [
      "Generics",
      "Abstract classes",
      "Interfaces",
      "Collection"
    ]
  },
  {
    numb: 6,
    question: "HashSet internally uses?",
    answer: " Set",
    options: [
      " Set",
      "HashMap",
      "List",
      "Collection"
    ]
  },
  {
    numb: 7,
    question: "The most used interfaces from the collection framework are? ",
    answer: "Map",
    options: [
      " List",
      "Map",
      "Set",
      "Collection"
    ]
  },
  {
    numb: 8,
    question: "The root interface of Java collection framework hierarchy is –",
    answer: " List/Set",
    options: [
      "Collection",
      "Root",
      "Collections",
      " List/Set"
    ]
  },
  {
    numb: 9,
    question: "Which of those is synchronized?",
    answer: "Vector",
    options: [
      "ArrayList",
      " LinkedList",
      "Vector",
      "None of the above"
    ]
  },
  {
    numb: 10,
    question: "ArrayList implements that of the following?",
    answer: " All of these",
    options: [
      " List",
      "RandomAccess",
      " Cloneable",
      " All of these"
    ]
  },
];