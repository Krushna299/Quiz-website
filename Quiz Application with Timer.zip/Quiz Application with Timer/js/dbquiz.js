let questions = [
    {
    numb: 1,
    question: "The DBMS acts as an interface between what two components of an enterprise-class database system?",
    answer: "Database application and the database",
    options: [
      "Database application and the database",
      "Data and the database",
      "The user and the database application",
      "Database application and SQL"
    ]
  },
    {
    numb: 2,
    question: "Which of the following products was an early implementation of the relational model developed by E.F. Codd of IBM?",
    answer: "DB2",
    options: [
      "IDMS",
      "DB2",
      "dBase-II",
      "R:base"
    ]
  },
    {
    numb: 3,
    question: "The following are components of a database except ________ .",
    answer: "reports",
    options: [
      "user data",
      "metadata",
      "reports",
      "indexes"
    ]
  },
    {
    numb: 4,
    question: "An application where only one user accesses the database at a given time is an example of a(n) ________ .",
    answer: "single-user database application",
    options: [
      "single-user database application",
      "multiuser database application",
      "e-commerce database application",
      "data mining database application"
    ]
  },
  {
    numb: 5,
    question: "Helping people keep track of things is the purpose of a(n) ________ .",
    answer: "database",
    options: [
      "table",
      "database",
      "instance",
      "relationship"
    ]
  },
  {
    numb: 6,
    question: "Which of the following products was the first to implement true relational algebra in a PC DBMS?",
    answer: "R:base",
    options: [
      "IDMS",
      "Oracle",
      "R:base",
      "dBase-II"
    ]
  },
  {
    numb: 7,
    question: "SQL stands for ________ .",
    answer: "Structured Query Language",
    options: [
      "Structured Query Language",
      "Sequential Query Language",
      "Structured Question Language",
      "Sequential Question Language"
    ]
  },
  {
    numb: 8,
    question: "Because it contains a description of its own structure, a database is considered to be ________ .",
    answer: "self-describing",
    options: [
      "described",
      "metadata compatible",
      "self-describing",
      "an application program"
    ]
  },
  {
    numb: 9,
    question: "The following are functions of a DBMS except ________ .",
    answer: "creating and processing forms",
    options: [
      "creating databases",
      "processing data",
      "administrating databases",
      "creating and processing forms"
    ]
  },
  
  {
    numb: 10,
    question: "An on-line commercial site such as Amazon.com is an example of a(n) ________ .",
    answer: "e-commerce database application",
    options: [
      "single-user database application",
      "multiuser database application",
      "e-commerce database application",
      "data mining database application"
    ]
  },
];