let questions = [
    {
    numb: 1,
    question: "What is the output of following code− [ (a,b) for a in range(3) for b in range(a) ]",
    answer: "[ (1,0),(2,0),(2,1)]",
    options: [
      "[ (1,0),(2,1),(3,2)]",
      "[ (0,0),(1,1),(2,2)]",
      "[(1,0),(2,1),(2,1)]",
      "[ (1,0),(2,0),(2,1)]"
    ]
  },
    {
    numb: 2,
    question: "Name the error that doesn’t cause program to stop/end, but the output is not the desired result or is incorrect.",
    answer: "Logical error",
    options: [
      "Syntax error",
      "Runtime error",
      "Logical error",
      "All of the above"
    ]
  },
    {
    numb: 3,
    question: "What is the output for− 'you are doing well' [2:999]",
    answer: " 'u are doing well'",
    options: [
      "'you are doing well'",
      "' '",
      "Index error.",
      " 'u are doing well'"
    ]
  },
    {
    numb: 4,
    question: "Suppose we are given with two sets(s1&s2) then what is the output of the code− S1 + S2 ",
    answer: " It is an illegal command.",
    options: [
      "Adds the elements of the both the sets.",
      "Removes the repeating elements and adds both the sets.",
      "Output will be stored in S1.",
      " It is an illegal command."
    ]
  },
    {
    numb: 5,
    question: "Which is the special symbol used in python to add comments?What does XML stand for?",
    answer: "#",
    options: [
      "$",
      "//",
      "#",
      "/*.... */"
    ]
  },
  {
    numb: 6,
    question: "How will you not create a dictionary?",
    answer: " d = { ('milk', 50), ('celery', 40) }",
    options: [
      " d = {'milk': 50, 'celery': 40}",
      " d = { ('milk', 50), ('celery', 40) }",
      "d = dict(milk=50, celery=40)",
      "d = dict([ ('milk', 50), ('celery', 40) ])"
    ]
  },
  {
    numb: 7,
    question: "In the following code, what is the output? a = 2,b = 3 ,a and b",
    answer: "3",
    options: [
      "3",
      "True",
      "False",
      "1"
    ]
  },
  {
    numb: 8,
    question: "What is the value of round(12.5) – round(11.5)?",
    answer: "0",
    options: [
      "0",
      "1",
      "2",
      "3"
    ]
  },
  {
    numb: 9,
    question: "What is the size of an empty tuple in Python?",
    answer: "48 bytes",
    options: [
      "0 bytes",
      "8 bytes",
      "32 bytes",
      "48 bytes"
    ]
  },
  {
    numb: 10,
    question: "What is the value of this expression? 2**2**3**1",
    answer: "256",
    options: [
      "12",
      "64",
      "128",
      "256"
    ]
  },
];